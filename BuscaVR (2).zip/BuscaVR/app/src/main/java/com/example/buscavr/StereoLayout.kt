package com.example.buscavr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import kotlin.math.abs

/** Mostra o WebView duas vezes lado a lado (um para cada olho). */
class StereoLayout(ctx: Context) : ViewGroup(ctx) {
    private var web: WebView? = null
    private var bmp: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    var sep = 0f // aproxima (+) ou afasta (-) as duas imagens, em pixels

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downT = 0L
    private var moved = false

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.BLACK)
    }

    fun attach(w: WebView) {
        web = w
        w.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        addView(w, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        requestLayout()
        invalidate()
    }

    fun detach() {
        web?.let {
            it.setLayerType(View.LAYER_TYPE_NONE, null)
            removeView(it)
        }
        web = null
        bmp = null
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        web?.measure(
            MeasureSpec.makeMeasureSpec(w / 2, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        web?.layout(0, 0, (r - l) / 2, b - t)
    }

    // Não desenha o filho direto: ele é desenhado duas vezes no onDraw.
    override fun dispatchDraw(canvas: Canvas) {}

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = web ?: return
        val hw = width / 2
        if (hw <= 0 || height <= 0) return
        var bm = bmp
        if (bm == null || bm.width != hw || bm.height != height) {
            bm = Bitmap.createBitmap(hw, height, Bitmap.Config.ARGB_8888)
            bmp = bm
        }
        val c = Canvas(bm)
        c.drawColor(Color.WHITE)
        w.draw(c)

        val hwf = hw.toFloat()
        val hf = height.toFloat()
        canvas.save()
        canvas.clipRect(0f, 0f, hwf, hf)
        canvas.drawBitmap(bm, sep, 0f, paint)
        canvas.restore()
        canvas.save()
        canvas.clipRect(hwf, 0f, width.toFloat(), hf)
        canvas.drawBitmap(bm, hwf - sep, 0f, paint)
        canvas.restore()

        val r = height * 0.012f + 3f
        canvas.drawCircle(hwf / 2f + sep, hf / 2f, r, dot)
        canvas.drawCircle(hwf * 1.5f - sep, hf / 2f, r, dot)
        postInvalidateDelayed(50)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = true

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = web ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                downT = e.eventTime; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 16 || abs(e.y - downY) > 16) moved = true
                if (moved) w.scrollBy((lastX - e.x).toInt(), (lastY - e.y).toInt())
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && e.eventTime - downT < 500) click(w)
            }
        }
        return true
    }

    // Toque rápido = clique no ponto vermelho (centro da tela de cada olho).
    private fun click(w: WebView) {
        val x = w.width / 2f
        val y = w.height / 2f
        val t = SystemClock.uptimeMillis()
        val d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        val u = MotionEvent.obtain(t, t + 50, MotionEvent.ACTION_UP, x, y, 0)
        w.dispatchTouchEvent(d)
        w.dispatchTouchEvent(u)
        d.recycle()
        u.recycle()
    }
}
