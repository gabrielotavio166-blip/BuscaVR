package com.example.buscavr

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var stereo: StereoLayout
    private lateinit var normal: LinearLayout
    private lateinit var holder: FrameLayout
    private lateinit var input: EditText
    private var vr = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        input = EditText(this).apply {
            hint = "Pesquisar ou digitar endereço"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        val vrBtn = Button(this).apply {
            text = "VR"
            setOnClickListener { setVr(true) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 16, 16, 16)
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(vrBtn)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) {
                    if (!input.hasFocus()) input.setText(url)
                }
            }
        }
        holder = FrameLayout(this).apply { addView(web) }

        normal = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        stereo = StereoLayout(this).apply { visibility = View.GONE }

        setContentView(FrameLayout(this).apply {
            addView(normal, FrameLayout.LayoutParams(-1, -1))
            addView(stereo, FrameLayout.LayoutParams(-1, -1))
        })

        web.loadUrl("https://www.google.com")
    }

    private fun go(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
        input.clearFocus()
    }

    @Suppress("DEPRECATION")
    private fun setVr(on: Boolean) {
        vr = on
        (web.parent as? ViewGroup)?.removeView(web)
        if (on) {
            normal.visibility = View.GONE
            stereo.visibility = View.VISIBLE
            stereo.attach(web)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else {
            stereo.detach()
            stereo.visibility = View.GONE
            normal.visibility = View.VISIBLE
            holder.addView(web)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window.decorView.systemUiVisibility = 0
        }
    }

    // Em VR: volume ajusta a distância entre as duas imagens.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (vr && keyCode == KeyEvent.KEYCODE_VOLUME_UP) { stereo.sep += 4f; return true }
        if (vr && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) { stereo.sep -= 4f; return true }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            vr -> setVr(false)
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }
}
