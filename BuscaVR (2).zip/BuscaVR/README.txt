Busca VR - navegador Android com tela dividida para óculos VR.

Como gerar o app:
1. Instale o Android Studio (no computador).
2. File > Open > escolha a pasta BuscaVR e espere o Gradle sincronizar.
3. Conecte o celular (depuração USB) e clique em Run, ou use Build > Build APK(s).

Como usar:
- Digite um endereço ou uma pesquisa e toque em Ir no teclado.
- Toque em "VR" para dividir a tela (o celular vai para a horizontal).
- Em VR: arraste para rolar; toque rápido clica no ponto vermelho do centro.
- Volume + / - aproxima ou afasta as duas imagens (ajuste para seu óculos).
- Botão Voltar sai do VR.
